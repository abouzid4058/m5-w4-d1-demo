/**
 * on-click.js
 * React class component that displays multiple HTML elements.
 * When any element is clicked, an alert shows its DOM id.
 */

class OnClickElements extends React.Component {
  // Constructor initializes the component (no state needed here)
  constructor(props) {
    super(props);
  }

  /**
   * handleClick - called whenever any element is clicked.
   * Uses the event object to read the id of the clicked target.
   * @param {SyntheticEvent} event - React's synthetic click event
   */
  handleClick(event) {
    alert(`hey! you clicked: ${event.target.id}`);
  }

  render() {
    return (
      <div className="container-div">

        {/* ── Group 1: plain inline elements ── */}

        {/* DIV element - plain text div */}
        <div
          id="div-element"
          onClick={(e) => this.handleClick(e)}
        >
          I am DIV
        </div>

        {/* SPAN element */}
        <span
          id="span-element"
          onClick={(e) => this.handleClick(e)}
        >
          I am SPAN
        </span>
        <br />

        {/* BUTTON element */}
        <button
          id="button-element"
          onClick={(e) => this.handleClick(e)}
        >
          I am Button
        </button>
        <br />

        {/* LINK (anchor) element */}
        <a
          id="link-element"
          href=""
          onClick={(e) => { e.preventDefault(); this.handleClick(e); }}
        >
          I am LINK
        </a>

        <br /><br />

        {/* ── Group 2: styled as buttons ── */}

        {/* DIV styled as button */}
        <div
          id="div-element-2"
          className="button-style"
          onClick={(e) => this.handleClick(e)}
        >
          I am DIV
        </div>

        {/* SPAN styled as button */}
        <span
          id="span-element-2"
          className="button-style"
          onClick={(e) => this.handleClick(e)}
        >
          I am SPAN
        </span>
        <br />

        {/* BUTTON styled */}
        <button
          id="button-element-2"
          className="button-style"
          onClick={(e) => this.handleClick(e)}
        >
          I am Button
        </button>
        <br />

        {/* LINK styled as button */}
        <a
          id="link-element-2"
          className="button-style"
          href=""
          onClick={(e) => { e.preventDefault(); this.handleClick(e); }}
        >
          I am LINK
        </a>

      </div>
    );
  }
}

// Mount the React component into the #root div in index.html
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<OnClickElements />);
